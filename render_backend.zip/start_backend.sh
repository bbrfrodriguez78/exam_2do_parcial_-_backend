#!/bin/bash
waitress-serve --port=$PORT backend:app