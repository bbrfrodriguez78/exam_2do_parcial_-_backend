#!/bin/bash
waitress-serve --port=$PORT frontend:app